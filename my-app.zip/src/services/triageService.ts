import type { Department, QueueItem, TriageQueryInput, TriageResult } from '../domain/types';
import { createQueueNo } from './queueService';

// 模拟患者、挂号、症状、科室数据（可替换为后端接口）
const mockPatients = [
  { patientId: 'p1', name: '王小明', idCard: '110*********1234', registrationNo: 'R-2025001', departmentId: 'dept-internal', departmentName: '内科', location: '一楼A区', symptoms: '头痛、发热38.5℃、咳嗽' },
  { patientId: 'p2', name: '李华', idCard: '320*********5678', registrationNo: 'R-2025002', departmentId: 'dept-ent', departmentName: '耳鼻喉', location: '二楼B区', symptoms: '咽痛、流涕' }
];

const departmentMap: Record<string, Department & { id: string }> = {
  'dept-internal': { id: 'dept-internal', name: '内科', location: '一楼A区' },
  'dept-ent': { id: 'dept-ent', name: '耳鼻喉', location: '二楼B区' },
  'dept-resp': { id: 'dept-resp', name: '呼吸科', location: '三楼C区' }
};

function mockCheckMatch(deptId: string, symptoms: string): boolean {
  if (deptId === 'dept-ent' && symptoms.includes('咳嗽')) return false;
  return true;
}

function mockRecommendDepartment(symptoms: string): Department {
  if (symptoms.includes('咳嗽') || symptoms.includes('发热')) return departmentMap['dept-resp'];
  return departmentMap['dept-internal'];
}

export function triageQuery(input: TriageQueryInput): { patient: typeof mockPatients[0]; targetDepartment: Department } {
  const { queryNo } = input;
  let patient = mockPatients.find((p) => p.idCard === queryNo || p.registrationNo === queryNo);
  if (!patient) {
    throw new Error('未查询到患者挂号信息，请核对输入');
  }
  const applyDepartment = departmentMap[patient.departmentId];
  if (!applyDepartment) {
    throw new Error('申请科室不存在');
  }

  const isMatch = mockCheckMatch(patient.departmentId, patient.symptoms);
  const targetDept = isMatch ? applyDepartment : mockRecommendDepartment(patient.symptoms);

  return { patient, targetDepartment: targetDept };
}

export function triageConfirm(
  input: TriageQueryInput,
  queue: QueueItem[]
): { queue: QueueItem[]; result: TriageResult } {
  const { patient, targetDepartment } = triageQuery(input);

  const existingMax = queue
    .filter((q) => q.department === targetDepartment.name)
    .reduce((max, item) => Math.max(max, parseInt(item.queueNo.replace(/\D/g, '') || '0', 10)), 0);
  const queueNoNumeric = existingMax + 1;
  const queueNo = createQueueNo(targetDepartment.name.startsWith('内') ? 'A' : 'B') + queueNoNumeric;

  const newItem: QueueItem = {
    id: crypto.randomUUID(),
    patientName: patient.name,
    idCard: patient.idCard,
    queueNo,
    status: 'waiting',
    estimatedWaitingTime: Math.max(5, queue.filter((q) => q.status !== 'done').length * 5),
    department: targetDepartment.name,
    location: targetDepartment.location,
    joinedAt: Date.now()
  };

  const result: TriageResult = {
    patientName: patient.name,
    patientId: patient.patientId,
    targetDepartment: targetDepartment.name,
    queueNo: queueNoNumeric,
    departmentLocation: targetDepartment.location,
    matchStatus: targetDepartment.name === departmentMap[patient.departmentId]?.name ? '匹配' : '已调整',
    applyDepartment: departmentMap[patient.departmentId]?.name || '',
    symptoms: patient.symptoms
  };

  return { queue: [...queue, newItem], result };
}

