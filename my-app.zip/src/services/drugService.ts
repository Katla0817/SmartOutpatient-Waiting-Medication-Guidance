import { drugStore } from '../data/drugStore';
import type { Drug } from '../domain/types';

export function queryDrugs(keyword: string): Drug[] {
  const q = keyword.trim().toLowerCase();
  if (!q) return drugStore;
  return drugStore.filter(
    (d) =>
      d.name.toLowerCase().includes(q) ||
      d.aliases.some((a) => a.toLowerCase().includes(q)) ||
      d.indications.toLowerCase().includes(q)
  );
}

