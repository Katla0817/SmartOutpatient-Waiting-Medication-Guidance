import type { QueueItem, QueueStatus } from '../domain/types';

export function createQueueNo(prefix = 'A'): string {
  return `${prefix}${Math.floor(Math.random() * 900 + 100)}`;
}

export function joinQueue(
  queue: QueueItem[],
  payload: { name: string; idCard: string; department: string; location: string }
): { queue: QueueItem[]; newItem: QueueItem; waitingCount: number } {
  const waitingCount = queue.filter((q) => q.status !== 'done').length;
  const estimatedWaitingTime = Math.max(5, waitingCount * 5);
  const newItem: QueueItem = {
    id: crypto.randomUUID(),
    patientName: payload.name,
    idCard: payload.idCard,
    queueNo: createQueueNo(),
    status: 'waiting',
    estimatedWaitingTime,
    department: payload.department,
    location: payload.location,
    joinedAt: Date.now()
  };
  return {
    queue: [...queue, newItem],
    newItem,
    waitingCount: waitingCount + 1
  };
}

export function tickQueue(queue: QueueItem[]): { queue: QueueItem[]; notes: string[] } {
  const newNotes: string[] = [];
  const updated = queue.map((item, idx) => {
    let status: QueueStatus = item.status;
    let eta = item.estimatedWaitingTime;

    if (idx === 0 && status === 'waiting') {
      status = 'calling';
      newNotes.push(`${item.queueNo} 正在叫号，请尽快前往诊室`);
    }

    if (status !== 'done' && eta > 0) {
      eta = Math.max(0, eta - 1);
    }

    if (status === 'calling' && eta === 0) {
      status = 'done';
      newNotes.push(`${item.queueNo} 已完成，请下一位准备`);
    }

    return { ...item, status, estimatedWaitingTime: eta };
  });

  return { queue: updated, notes: newNotes };
}

export function callNext(queue: QueueItem[]): { queue: QueueItem[]; note?: string } {
  const next = [...queue];
  const waitingIdx = next.findIndex((q) => q.status === 'waiting');
  if (waitingIdx >= 0) {
    next[waitingIdx] = { ...next[waitingIdx], status: 'calling', estimatedWaitingTime: 0 };
    return { queue: next, note: `${next[waitingIdx].queueNo} 正在叫号，请患者前往诊室` };
  }
  return { queue: next };
}

export function markCallingDone(queue: QueueItem[]): { queue: QueueItem[]; note?: string } {
  const next = [...queue];
  const callingIdx = next.findIndex((q) => q.status === 'calling');
  if (callingIdx >= 0) {
    next[callingIdx] = { ...next[callingIdx], status: 'done', estimatedWaitingTime: 0 };
    return { queue: next, note: `${next[callingIdx].queueNo} 已完成，就诊结束` };
  }
  return { queue: next };
}

