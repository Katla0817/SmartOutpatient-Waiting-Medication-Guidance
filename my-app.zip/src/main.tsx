import React, { useEffect, useMemo, useState } from 'react';
import ReactDOM from 'react-dom/client';
import './style.css';
import RegistrationForm from './regist';
import RegistrationResult from './regist2';
import type { Department, Notification, QueueItem } from './domain/types';
import { queryDrugs } from './services/drugService';
import { drugStore } from './data/drugStore';
import {
  callNext as callNextService,
  joinQueue,
  markCallingDone as markCallingDoneService,
  tickQueue
} from './services/queueService';
import { triageConfirm } from './services/triageService';

const departments: Department[] = [
  // 内科系
  { id: 'dept-internal', name: '普通内科', location: '一楼A区', category: '内科系', specialty: '常见内科症状', guide: '门诊大厅右侧，A区' },
  { id: 'dept-cardio', name: '心血管内科', location: '二楼B区', category: '内科系', specialty: '胸闷、心悸、高血压', guide: '乘1号电梯至二楼B区' },
  { id: 'dept-resp', name: '呼吸内科', location: '三楼C区', category: '内科系', specialty: '感冒、肺炎、咳嗽', guide: '三楼C区，1号电梯左转' },
  { id: 'dept-digest', name: '消化内科', location: '四楼D区', category: '内科系', specialty: '胃肠不适、反酸', guide: '四楼D区' },
  // 外科系
  { id: 'dept-surgery', name: '普通外科', location: '一楼E区', category: '外科系', specialty: '普外伤口、疝气', guide: '一楼E区' },
  { id: 'dept-ortho', name: '骨科', location: '二楼F区', category: '外科系', specialty: '骨折、关节疼痛', guide: '二楼F区' },
  { id: 'dept-neuro', name: '神经外科', location: '三楼G区', category: '外科系', specialty: '颅脑、脊柱相关', guide: '三楼G区' },
  { id: 'dept-uro', name: '泌尿外科', location: '四楼H区', category: '外科系', specialty: '泌尿结石、感染', guide: '四楼H区' },
  // 专科系
  { id: 'dept-ent', name: '耳鼻喉科', location: '二楼B区', category: '专科系', specialty: '咽痛、鼻炎、听力', guide: '二楼B区' },
  { id: 'dept-eye', name: '眼科', location: '三楼C区', category: '专科系', specialty: '视力、眼部不适', guide: '三楼C区' },
  { id: 'dept-obgyn', name: '妇产科', location: '四楼D区', category: '专科系', specialty: '女性健康', guide: '四楼D区' },
  { id: 'dept-ped', name: '儿科', location: '五楼E区', category: '专科系', specialty: '儿童常见病', guide: '五楼E区' },
  { id: 'dept-derm', name: '皮肤科', location: '一楼F区', category: '专科系', specialty: '皮疹、过敏', guide: '一楼F区' },
  { id: 'dept-dental', name: '口腔科', location: '二楼G区', category: '专科系', specialty: '牙痛、正畸', guide: '二楼G区' },
  { id: 'dept-er', name: '急诊科', location: '一楼急诊专区', category: '专科系', specialty: '急症处理', guide: '急诊专区' }
];

const formatTime = () => {
  const date = new Date();
  return `${date.getHours().toString().padStart(2, '0')}:${date
    .getMinutes()
    .toString()
    .padStart(2, '0')}:${date.getSeconds().toString().padStart(2, '0')}`;
};

function App() {
  const [isElderMode, setIsElderMode] = useState(false);
  type Role = 'patient' | 'nurse' | 'pharmacist';
  const [role, setRole] = useState<Role | null>(null);
  const [selectedDeptId, setSelectedDeptId] = useState<string>(departments[0].id);
  const [hasRegistration, setHasRegistration] = useState(false);
  const [result, setResult] = useState({
    success: true,
    departmentName: departments[0].name,
    location: departments[0].location,
    queueNo: 'A123',
    queueLength: 3,
    estimatedWaitingTime: 12,
    tips: '请在叫号前提前10分钟到达候诊区。',
    patientName: '演示患者',
    status: '候诊中'
  });
  const [queue, setQueue] = useState<QueueItem[]>([
    {
      id: 'seed-1',
      patientName: '张三',
      idCard: '110*********1234',
      queueNo: 'A101',
      status: 'calling',
      estimatedWaitingTime: 0,
      department: departments[0].name,
      location: departments[0].location,
      joinedAt: Date.now() - 5 * 60 * 1000
    },
    {
      id: 'seed-2',
      patientName: '李四',
      idCard: '320*********5678',
      queueNo: 'A102',
      status: 'waiting',
      estimatedWaitingTime: 8,
      department: departments[0].name,
      location: departments[0].location,
      joinedAt: Date.now() - 3 * 60 * 1000
    }
  ]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [drugQuery, setDrugQuery] = useState('');
  const [medQueryMode, setMedQueryMode] = useState<'barcode' | 'name' | null>(null);
  const [medBarcode, setMedBarcode] = useState('');
  const [medName, setMedName] = useState('');
  const [medDetailInfo, setMedDetailInfo] = useState<{
    name: string;
    indications: string;
    dosage: string;
    cautions: string;
  } | null>(null);
  const [medMessage, setMedMessage] = useState('');
  const [triageNo, setTriageNo] = useState('');
  const [triageResult, setTriageResult] = useState<
    | {
        patientName: string;
        patientId: string;
        targetDepartment: string;
        queueNo: number;
        departmentLocation: string;
        matchStatus: string;
        applyDepartment: string;
        symptoms: string;
      }
    | null
  >(null);
  const [triageError, setTriageError] = useState('');
  const currentDepartment = departments.find((d) => d.id === selectedDeptId) || departments[0];

  const filteredDrugs = useMemo(() => queryDrugs(drugQuery), [drugQuery]);

  const addNotification = (message: string) => {
    setNotifications((prev) => [
      { id: crypto.randomUUID(), message, time: formatTime() },
      ...prev
    ].slice(0, 6));
  };

  const handleRoleSwitch = (next: Role) => {
    setRole(next);
    if (next === 'patient') {
      addNotification('已切换到患者入口，可提交挂号并查看通知');
    } else if (next === 'nurse') {
      addNotification('已切换到护士入口，可查看并操作候诊队列');
    } else if (next === 'pharmacist') {
      addNotification('已切换到药师入口，可查询药品知识库');
    }
  };

  useEffect(() => {
    const timer = setInterval(() => {
      setQueue((prev) => {
        const { queue: next, notes } = tickQueue(prev);
        notes.forEach((n) => addNotification(n));
        return next;
      });
    }, 4000);

    return () => clearInterval(timer);
  }, []);

  const handleSubmit = (payload: { idCard: string; name: string }) => {
    const { queue: nextQueue, newItem, waitingCount } = joinQueue(queue, {
      name: payload.name,
      idCard: payload.idCard,
      department: currentDepartment.name,
      location: currentDepartment.location
    });
    setQueue(nextQueue);
    setResult({
      success: true,
      departmentName: currentDepartment.name,
      location: currentDepartment.location,
      queueNo: newItem.queueNo,
      queueLength: waitingCount,
      estimatedWaitingTime: newItem.estimatedWaitingTime,
      tips: '请保持手机畅通，关注叫号通知。',
      patientName: payload.name,
      status: '候诊中'
    });
    setHasRegistration(true);

    addNotification(`新挂号 ${newItem.queueNo} 已加入队列，当前前方 ${waitingCount - 1} 人`);
  };

  const handleQueryQueue = () => {
    const waitingCount = queue.filter((q) => q.status === 'waiting').length;
    addNotification(`当前等待 ${waitingCount} 人，队列实时刷新中`);
  };

  const callNextHandler = () => {
    setQueue((prev) => {
      const { queue: next, note } = callNextService(prev);
      if (note) addNotification(note);
      return next;
    });
  };

  const markCallingDoneHandler = () => {
    setQueue((prev) => {
      const { queue: next, note } = markCallingDoneService(prev);
      if (note) addNotification(note);
      return next;
    });
  };

  const handleTriage = () => {
    setTriageError('');
    try {
      const { queue: nextQueue, result } = triageConfirm({ queryNo: triageNo.trim() }, queue);
      setQueue(nextQueue);
      setTriageResult(result);
      addNotification(`分诊完成：${result.patientName} -> ${result.targetDepartment}，序号 ${result.queueNo}`);
    } catch (e: any) {
      setTriageError(e.message || '分诊失败');
      setTriageResult(null);
    }
  };

  const resetMedStates = () => {
    setMedDetailInfo(null);
    setMedMessage('');
  };

  const getMedDetailByName = (name: string) => {
    const detail = queryDrugs(name)[0] || drugStore.find((d) => d.name === name) || drugStore[0];
    return {
      name: detail.name,
      indications: detail.indications,
      dosage: detail.dosage,
      cautions: detail.cautions
    };
  };

  const submitMedQuery = () => {
    resetMedStates();
    if (medQueryMode === 'barcode') {
      if (!medBarcode.trim()) {
        setMedMessage('请输入或扫描药品条码后再提交。');
        return;
      }
      const sample = drugStore[0];
      setMedDetailInfo(getMedDetailByName(sample.name));
      setMedMessage(`已提交条码查询请求，并返回 ${sample.name} 的详细用药指导。`);
      addNotification('药品条码查询已提交，详细用药指导已返回。');
    } else if (medQueryMode === 'name') {
      const keyword = medName.trim();
      if (!keyword) {
        setMedMessage('请输入药品名称后再提交。');
        return;
      }
      const match = queryDrugs(keyword)[0];
      if (!match) {
        setMedMessage('未找到匹配的药品，请检查名称或尝试其他关键词。');
        return;
      }
      setMedDetailInfo(getMedDetailByName(match.name));
      setMedMessage(`已提交名称查询请求，并返回 ${match.name} 的详细用药指导。`);
      addNotification(`药品名称查询已提交：${match.name}（已返回详细指导）`);
    } else {
      setMedMessage('请选择扫描条码或输入药品名称。');
    }
  };

  const activeQueue = queue.filter((q) => q.status !== 'done');

  return (
    <div className="page">
      <div className="header">
        <div className="title">
          <h1>医院挂号与候诊队列</h1>
          <span>挂号、实时叫号通知、药品知识库一站式示例</span>
        </div>
        <div className="flex gap-4">
          <div className="chip">科室：{currentDepartment.name}</div>
          <div className="chip">地点：{currentDepartment.location}</div>
          <button className="btn btn-ghost" onClick={() => setIsElderMode((v) => !v)}>
            {isElderMode ? '切换普通模式' : '切换长者模式'}
          </button>
        </div>
      </div>

      {!role && (
        <section className="section">
          <div className="section-header">
            <h2>请选择您的角色</h2>
            <span className="pill">入口选择</span>
          </div>
          <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 12 }}>
            <div className="card">
              <h3>患者</h3>
              <p className="muted">挂号、查看队列与通知</p>
              <button className="btn btn-primary" onClick={() => handleRoleSwitch('patient')}>进入患者入口</button>
            </div>
            <div className="card">
              <h3>护士</h3>
              <p className="muted">队列管理、分诊、叫号</p>
              <button className="btn btn-primary" onClick={() => handleRoleSwitch('nurse')}>进入护士入口</button>
            </div>
            <div className="card">
              <h3>药师</h3>
              <p className="muted">药品知识库查询</p>
              <button className="btn btn-primary" onClick={() => handleRoleSwitch('pharmacist')}>进入药师入口</button>
            </div>
          </div>
        </section>
      )}

      {role && (
        <div className="flex gap-4" style={{ marginBottom: 12 }}>
          <button className="btn btn-ghost" onClick={() => setRole(null)}>返回角色选择</button>
          <span className="chip">当前：{role === 'patient' ? '患者' : role === 'nurse' ? '护士' : '药师'}</span>
        </div>
      )}

      {role === 'patient' && (
        <>
          <div className="grid">
            <section className="section">
              <div className="section-header">
                <h2>1) 患者挂号</h2>
                <span className="pill">加入候诊队列</span>
              </div>
              <RegistrationForm
              department={{ ...currentDepartment, waitingCount: activeQueue.length }}
              departments={departments}
              selectedDepartmentId={selectedDeptId}
              onDepartmentChange={setSelectedDeptId}
                onSubmit={handleSubmit}
                onBack={() => handleQueryQueue()}
                isElderMode={isElderMode}
              />
            </section>

            <section className="section">
              <div className="section-header">
                <h2>候诊队列 & 通知</h2>
                <span className="pill">实时刷新</span>
              </div>
              <div className="info-row">
                <span>当前等待</span>
                <strong>{activeQueue.length} 人</strong>
              </div>
              <div className="divider" />
              <div className="card-list">
                {activeQueue.map((item, idx) => (
                  <div className="card" key={item.id}>
                    <div className="flex-between">
                      <div className="flex gap-6">
                        <div className="chip">号源 {item.queueNo}</div>
                        <div className="chip">姓名 {item.patientName}</div>
                      </div>
                      <span className={`badge ${item.status}`}>
                        {item.status === 'waiting' && '等待中'}
                        {item.status === 'calling' && '正在叫号'}
                        {item.status === 'done' && '已完成'}
                      </span>
                    </div>
                    <div className="info-row">
                      <span>预计等待</span>
                      <strong>{item.estimatedWaitingTime} 分钟</strong>
                    </div>
                    <div className="info-row">
                      <span>排队位置</span>
                      <span>前方约 {idx} 人</span>
                    </div>
                  </div>
                ))}
                {activeQueue.length === 0 && (
                  <div className="muted">暂无等待患者，稍后自动刷新。</div>
                )}
              </div>

              <div className="divider" />
              <div className="section-header">
                <h3 style={{ fontSize: 16, margin: 0 }}>通知中心</h3>
                <button className="btn btn-ghost" onClick={handleQueryQueue}>
                  手动刷新
                </button>
              </div>
              <div className="card-list">
                {notifications.map((n) => (
                  <div className="card notification" key={n.id}>
                    <div>{n.message}</div>
                    <small>{n.time}</small>
                  </div>
                ))}
                {notifications.length === 0 && (
                  <div className="muted">暂无通知，队列变化后会自动推送。</div>
                )}
              </div>
            </section>
          </div>

          <section className="section">
            <div className="section-header">
              <h2>2) 你的挂号信息</h2>
              <span className="pill">最新挂号</span>
            </div>
            {hasRegistration ? (
              <RegistrationResult
                result={result}
                onBackToHome={handleQueryQueue}
                onQueryQueue={handleQueryQueue}
                isElderMode={isElderMode}
              />
            ) : (
              <div className="muted">暂无挂号记录，请先完成挂号。</div>
            )}
          </section>

          <section className="section">
            <div className="section-header">
              <h2>3) 用药查询</h2>
              <span className="pill">患者端</span>
            </div>
            <div className="flex gap-3" style={{ flexWrap: 'wrap', marginBottom: 12 }}>
              <button
                className={`btn ${medQueryMode === 'barcode' ? 'btn-primary' : 'btn-ghost'}`}
                onClick={() => {
                  setMedQueryMode('barcode');
                  setMedName('');
                  resetMedStates();
                }}
              >
                扫描药品条码
              </button>
              <button
                className={`btn ${medQueryMode === 'name' ? 'btn-primary' : 'btn-ghost'}`}
                onClick={() => {
                  setMedQueryMode('name');
                  setMedBarcode('');
                  resetMedStates();
                }}
              >
                输入药品名称
              </button>
            </div>

            {medQueryMode && (
              <div className="card" style={{ marginBottom: 12 }}>
                <div className="section-header" style={{ margin: 0 }}>
                  <h3 style={{ margin: 0 }}>
                    {medQueryMode === 'barcode' ? '扫描条码' : '输入药名'}查询
                  </h3>
                  <span className="pill">
                    {medQueryMode === 'barcode' ? '条码查询' : '名称查询'}
                  </span>
                </div>
                {medQueryMode === 'barcode' && (
                  <div className="flex gap-4" style={{ marginTop: 12 }}>
                    <input
                      className="input"
                      placeholder="点击扫码或输入条码号"
                      value={medBarcode}
                      onChange={(e) => setMedBarcode(e.target.value)}
                      style={{ fontSize: isElderMode ? 18 : 14, padding: isElderMode ? '14px' : '10px' }}
                    />
                    <button className="btn btn-primary" onClick={submitMedQuery}>
                      提交条码查询请求
                    </button>
                  </div>
                )}
                {medQueryMode === 'name' && (
                  <div className="flex gap-4" style={{ marginTop: 12 }}>
                    <input
                      className="input"
                      placeholder="输入药品名称，如 布洛芬"
                      value={medName}
                      onChange={(e) => setMedName(e.target.value)}
                      style={{ fontSize: isElderMode ? 18 : 14, padding: isElderMode ? '14px' : '10px' }}
                    />
                    <button className="btn btn-primary" onClick={submitMedQuery}>
                      提交名称查询请求
                    </button>
                  </div>
                )}
                {medMessage && <div className="muted" style={{ marginTop: 10 }}>{medMessage}</div>}
              </div>
            )}


            {medDetailInfo && (
              <div
                className="card"
                style={{
                  background: '#f8fafc',
                  border: '1px solid #e2e8f0',
                  fontSize: isElderMode ? 18 : 14,
                  lineHeight: isElderMode ? '1.8' : '1.6'
                }}
              >
                <div className="section-header" style={{ margin: 0 }}>
                  <h3 style={{ margin: 0 }}>详细用药指导</h3>
                  <span className="pill">适老化支持</span>
                </div>
                <p><strong>药品名称：</strong>{medDetailInfo.name}</p>
                <p><strong>适应症：</strong>{medDetailInfo.indications}</p>
                <p><strong>用法用量：</strong>{medDetailInfo.dosage}</p>
                <p><strong>禁忌 / 注意事项：</strong>{medDetailInfo.cautions}</p>
                <div className="muted" style={{ marginTop: 8 }}>
                  信息仅供参考，请遵循医师和药师指导。
                </div>
              </div>
            )}
          </section>
        </>
      )}

      {role === 'nurse' && (
        <>
          <section className="section">
            <div className="section-header">
              <h2>护士视角：队列管理</h2>
              <div className="flex gap-4">
                <button className="btn btn-primary" onClick={callNextHandler}>叫下一位</button>
                <button className="btn btn-ghost" onClick={markCallingDoneHandler}>标记完成</button>
              </div>
            </div>
            <div className="info-row">
              <span>等待中</span>
              <strong>{queue.filter((q) => q.status === 'waiting').length} 人</strong>
            </div>
            <div className="info-row">
              <span>正在叫号</span>
              <strong>{queue.filter((q) => q.status === 'calling').length} 人</strong>
            </div>
            <div className="divider" />
            <div className="card-list">
              {queue.map((item) => (
                <div className="card" key={item.id}>
                  <div className="flex-between">
                    <div className="flex gap-6">
                      <div className="chip">号源 {item.queueNo}</div>
                      <div className="chip">姓名 {item.patientName}</div>
                    </div>
                    <span className={`badge ${item.status}`}>
                      {item.status === 'waiting' && '等待中'}
                      {item.status === 'calling' && '正在叫号'}
                      {item.status === 'done' && '已完成'}
                    </span>
                  </div>
                  <div className="info-row">
                    <span>预计等待</span>
                    <strong>{item.estimatedWaitingTime} 分钟</strong>
                  </div>
                  <div className="info-row">
                    <span>加入时间</span>
                    <span>{new Date(item.joinedAt).toLocaleTimeString()}</span>
                  </div>
                </div>
              ))}
              {queue.length === 0 && <div className="muted">暂无队列。</div>}
            </div>
          </section>

          <section className="section">
            <div className="section-header">
              <h2>护士分诊操作</h2>
              <span className="pill">分诊单生成</span>
            </div>
            <div className="flex gap-4" style={{ marginBottom: 12 }}>
              <input
                className="input"
                placeholder="输入挂号单号或身份证号，例如 R-2025001"
                value={triageNo}
                onChange={(e) => setTriageNo(e.target.value)}
              />
              <button className="btn btn-primary" onClick={handleTriage}>查询并分诊</button>
            </div>
            {triageError && <div className="muted" style={{ color: '#ef4444' }}>{triageError}</div>}
            {triageResult && (
              <div className="card">
                <div className="flex-between">
                  <div className="chip">患者 {triageResult.patientName}</div>
                  <div className="chip">匹配度：{triageResult.matchStatus}</div>
                </div>
                <div className="info-row">
                  <span>申请科室</span>
                  <strong>{triageResult.applyDepartment}</strong>
                </div>
                <div className="info-row">
                  <span>目标科室</span>
                  <strong>{triageResult.targetDepartment}</strong>
                </div>
                <div className="info-row">
                  <span>候诊序号</span>
                  <strong>{triageResult.queueNo}</strong>
                </div>
                <div className="info-row">
                  <span>科室位置</span>
                  <span>{triageResult.departmentLocation}</span>
                </div>
                <div className="info-row">
                  <span>症状描述</span>
                  <span>{triageResult.symptoms}</span>
                </div>
                <div className="flex gap-4" style={{ marginTop: 12 }}>
                  <button className="btn btn-primary">打印分诊单</button>
                  <button className="btn btn-ghost" onClick={() => setTriageResult(null)}>返回查询</button>
                </div>
              </div>
            )}
          </section>

          <section className="section">
            <div className="section-header">
              <h3 style={{ margin: 0 }}>通知中心</h3>
              <button className="btn btn-ghost" onClick={handleQueryQueue}>
                手动刷新
              </button>
            </div>
            <div className="card-list">
              {notifications.map((n) => (
                <div className="card notification" key={n.id}>
                  <div>{n.message}</div>
                  <small>{n.time}</small>
                </div>
              ))}
              {notifications.length === 0 && (
                <div className="muted">暂无通知，队列变化后会自动推送。</div>
              )}
            </div>
          </section>
        </>
      )}

      {role === 'pharmacist' && (
        <section className="section">
          <div className="section-header">
            <h2>药师视角：药品知识库查询</h2>
            <span className="pill">示例数据</span>
          </div>
          <div className="flex gap-4" style={{ marginBottom: 12 }}>
            <input
              className="input"
              placeholder="输入药品名 / 别名 / 适应症关键词，例如 '发热'、'布洛芬'"
              value={drugQuery}
              onChange={(e) => setDrugQuery(e.target.value)}
            />
            <button className="btn btn-primary" onClick={() => setDrugQuery(drugQuery.trim())}>
              查询
            </button>
          </div>
          <div className="list">
            {filteredDrugs.map((d) => (
              <div className="card kb-item" key={d.name}>
                <div className="flex-between">
                  <h3>{d.name}</h3>
                  <span className="badge waiting">知识库</span>
                </div>
                <p><strong>别名：</strong>{d.aliases.join(' / ')}</p>
                <p><strong>适应症：</strong>{d.indications}</p>
                <p><strong>用法用量：</strong>{d.dosage}</p>
                <p><strong>注意事项：</strong>{d.cautions}</p>
                <div className="kb-tags">
                  {d.aliases.map((a) => (
                    <span className="chip" key={a}>{a}</span>
                  ))}
                </div>
              </div>
            ))}
            {filteredDrugs.length === 0 && (
              <div className="muted">未找到匹配的药品，请尝试其他关键词。</div>
            )}
          </div>
        </section>
      )}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('app')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

