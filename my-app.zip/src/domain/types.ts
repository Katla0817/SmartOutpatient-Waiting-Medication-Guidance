export type QueueStatus = 'waiting' | 'calling' | 'done';

export type Department = {
  id: string;
  name: string;
  location: string;
  category?: string;
  guide?: string;
  specialty?: string;
};

export type QueueItem = {
  id: string;
  patientName: string;
  idCard: string;
  queueNo: string;
  status: QueueStatus;
  estimatedWaitingTime: number;
  department: string;
  location: string;
  joinedAt: number;
};

export type Notification = {
  id: string;
  message: string;
  time: string;
};

export type Drug = {
  name: string;
  aliases: string[];
  indications: string;
  dosage: string;
  cautions: string;
};

export type TriageQueryInput = {
  queryNo: string; // 挂号单号或身份证号
};

export type TriageResult = {
  patientName: string;
  patientId: string;
  targetDepartment: string;
  queueNo: number;
  departmentLocation: string;
  matchStatus: '匹配' | '已调整';
  applyDepartment: string;
  symptoms: string;
};

