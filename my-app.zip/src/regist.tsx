import { useState, type FormEvent } from 'react';

type DepartmentOption = {
  id: string;
  name: string;
  location: string;
};

type Department = DepartmentOption & {
  waitingCount: number;
};

interface RegistrationFormProps {
  department: Department;
  departments: DepartmentOption[];
  selectedDepartmentId: string;
  onDepartmentChange: (id: string) => void;
  onSubmit: (payload: { idCard: string; name: string }) => void;
  onBack: () => void;
  isElderMode: boolean;
}

export default function RegistrationForm({
  department,
  departments,
  selectedDepartmentId,
  onDepartmentChange,
  onSubmit,
  onBack,
  isElderMode
}: RegistrationFormProps) {
  const [idCard, setIdCard] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [nameError, setNameError] = useState('');
  const [idError, setIdError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const filteredDepartments = departments;

  const validateName = (value: string) => {
    if (!value) return '请输入姓名';
    if (!/^[\u4e00-\u9fa5]{2,5}$/.test(value)) return '姓名限2-5个汉字';
    return '';
  };

  const validateId = (value: string) => {
    if (!value) return '请输入身份证号码';
    if (!/^\d{17}[\dXx]$/.test(value)) {
      const remain = Math.max(0, 18 - value.length);
      return value.length < 18 ? `还需输入 ${remain} 位` : '请输入正确的18位身份证号';
    }
    return '';
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const nErr = validateName(name);
    const iErr = validateId(idCard);
    setNameError(nErr);
    setIdError(iErr);
    if (nErr || iErr) {
      setError('请完善姓名、身份证号');
      return;
    }
    setError('');
    setSubmitting(true);
    onSubmit({ idCard, name: name.trim() });
    setSubmitting(false);
  };

return (
  <div className={`bg-white rounded-2xl shadow-lg p-8 ${isElderMode ? 'text-2xl' : 'text-base'}`}>
      <div className="flex justify-between items-start mb-8">
        <div>
          <h2 className={`font-bold text-gray-900 ${isElderMode ? 'text-3xl' : 'text-xl'}`}>
            挂号信息填写
          </h2>
          <p className={`text-gray-600 mt-2 ${isElderMode ? 'text-xl' : 'text-sm'}`}>
            请填写您的身份信息完成挂号
          </p>
        </div>
        <button 
          onClick={onBack}
          className={`flex items-center space-x-1 px-4 py-2 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors ${
            isElderMode ? 'text-xl' : 'text-sm'
          }`}
        >
          <i className="ri-arrow-left-line"></i>
          <span>返回</span>
        </button>
      </div>

      {/* 科室信息卡片 */}
      <div className="bg-blue-50 rounded-xl p-6 mb-8 border border-blue-100">
        <div className="mb-4">
          <label
            htmlFor="department"
            className={`block text-gray-700 mb-2 ${isElderMode ? 'text-xl' : 'text-sm'}`}
          >
            选择科室
          </label>
          {!isElderMode && (
            <select
              id="department"
              value={selectedDepartmentId}
              onChange={(e) => onDepartmentChange(e.target.value)}
              className={`w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                isElderMode ? 'text-xl py-4' : 'text-base'
              }`}
            >
              {filteredDepartments.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </select>
          )}
          {isElderMode && (
            <div className="card-list" style={{ maxHeight: 260, overflowY: 'auto' }}>
              {filteredDepartments.map((d) => (
                <button
                  key={d.id}
                  type="button"
                  onClick={() => onDepartmentChange(d.id)}
                  className={`btn ${selectedDepartmentId === d.id ? 'btn-primary' : 'btn-ghost'}`}
                  style={{ width: '100%', justifyContent: 'flex-start' }}
                >
                  {d.name}（{d.location}）
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="flex items-start">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center mr-4">
            <i className="ri-hospital-line text-white text-2xl"></i>
          </div>
          <div>
            <h3 className={`font-bold text-gray-900 ${isElderMode ? 'text-2xl' : 'text-lg'}`}>
              {department.name}
            </h3>
            <div className="mt-2">
              <div className="flex items-center text-gray-600">
                <i className="ri-map-pin-line mr-2"></i>
                <span>{department.location}</span>
              </div>
              {(department as any).specialty && (
                <div className="flex items-center text-gray-600 mt-1">
                  <i className="ri-information-line mr-2"></i>
                  <span>科室说明：{(department as any).specialty}</span>
                </div>
              )}
              {(department as any).guide && (
                <div className="flex items-center text-gray-600 mt-1">
                  <i className="ri-guide-fill mr-2"></i>
                  <span>楼层指引：{(department as any).guide}</span>
                </div>
              )}
              <div className="flex items-center text-gray-600 mt-1">
                <i className="ri-group-line mr-2"></i>
                <span>当前等待: {department.waitingCount}人</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 表单区域 */}
      <form onSubmit={handleSubmit}>
        <div className="mb-6">
          <label 
            htmlFor="name" 
            className={`block text-gray-700 mb-2 ${isElderMode ? 'text-xl' : 'text-sm'}`}
          >
            患者姓名
          </label>
          <input
            id="name"
            type="text"
            value={name}
            onChange={(e) => {
              setName(e.target.value);
              const err = validateName(e.target.value);
              setNameError(err);
              setError(err ? '请完善姓名' : '');
            }}
            placeholder="请输入姓名"
            className={`w-full px-4 py-3 border ${error && !name ? 'border-red-500' : 'border-gray-300'} rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 ${
              isElderMode ? 'text-xl py-4' : 'text-base'
            }`}
          />
          {nameError && (
            <p className="text-red-500 mt-2 flex items-center">
              <i className="ri-error-warning-line mr-2"></i>
              {nameError}
            </p>
          )}
        </div>
        <div className="mb-6">
          <label 
            htmlFor="idCard" 
            className={`block text-gray-700 mb-2 ${isElderMode ? 'text-xl' : 'text-sm'}`}
          >
            身份证号码 {idCard.length > 0 && idCard.length < 18 && `（还需 ${18 - idCard.length} 位）`}
          </label>
          <input
            id="idCard"
            type="text"
            value={idCard}
            onChange={(e) => {
              setIdCard(e.target.value);
              const err = validateId(e.target.value);
              setIdError(err);
              setError(err ? '请输入正确的身份证号' : '');
            }}
            placeholder="请输入18位身份证号码"
            className={`w-full px-4 py-3 border ${error ? 'border-red-500' : 'border-gray-300'} rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 ${
              isElderMode ? 'text-xl py-4' : 'text-base'
            }`}
          />
          {(idError || error) && (
            <p className="text-red-500 mt-2 flex items-center">
              <i className="ri-error-warning-line mr-2"></i>
              {idError || error}
            </p>
          )}
        </div>

        <div className="flex justify-end space-x-4">
          <button
            type="button"
            onClick={onBack}
            className={`px-6 py-3 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition-colors ${
              isElderMode ? 'text-xl px-8 py-4' : 'text-base'
            }`}
          >
            返回
          </button>
          <button
            type="submit"
            disabled={!!validateName(name) || !!validateId(idCard) || submitting}
            className={`px-6 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl hover:from-blue-600 hover:to-indigo-700 shadow-md hover:shadow-lg transition-all ${
              isElderMode ? 'text-xl px-8 py-4' : 'text-base'
            } ${submitting || validateName(name) || validateId(idCard) ? 'opacity-60 cursor-not-allowed' : ''}`}
          >
            <i className="ri-check-line mr-2"></i>
            {submitting ? '提交中...' : '确认挂号'}
          </button>
        </div>
      </form>
    </div>
  );
}