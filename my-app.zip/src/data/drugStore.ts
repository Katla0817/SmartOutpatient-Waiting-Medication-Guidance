import type { Drug } from '../domain/types';

export const drugStore: Drug[] = [
  {
    name: '对乙酰氨基酚',
    aliases: ['扑热息痛', 'Paracetamol'],
    indications: '用于普通感冒或流感引起的发热、轻中度疼痛。',
    dosage: '成人每次0.5~1g，每4~6小时一次；24小时不超过4g。',
    cautions: '肝功能异常慎用，避免与含对乙酰氨基酚的其他药同服。'
  },
  {
    name: '布洛芬',
    aliases: ['Ibuprofen'],
    indications: '用于缓解轻中度疼痛，如头痛、牙痛、关节痛，并退热。',
    dosage: '成人每次0.2~0.4g，每4~6小时一次；24小时不超过1.2g（OTC）。',
    cautions: '胃溃疡、出血倾向、哮喘者慎用，避免空腹服用。'
  },
  {
    name: '阿莫西林',
    aliases: ['Amoxicillin'],
    indications: '青霉素类抗生素，适用于敏感菌所致的呼吸道、泌尿道等感染。',
    dosage: '成人每次0.5g，每8小时一次；具体遵医嘱完成疗程。',
    cautions: '青霉素过敏禁用，注意皮疹、腹泻等不良反应。'
  }
];

