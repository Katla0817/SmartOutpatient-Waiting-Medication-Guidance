interface RegistrationResultData {
  success: boolean;
  departmentName: string;
  location: string;
  queueNo: string;
  queueLength: number;
  estimatedWaitingTime: number;
  tips: string;
  patientName?: string;
  status?: string;
}

interface RegistrationResultProps {
  result: RegistrationResultData;
  onBackToHome: () => void;
  onQueryQueue: () => void;
  isElderMode: boolean;
}

export default function RegistrationResult({
  result,
  onBackToHome,
  onQueryQueue,
  isElderMode
}: RegistrationResultProps) {
  return (
    <div className={`bg-white rounded-2xl shadow-lg p-8 text-center ${isElderMode ? 'text-2xl' : 'text-base'}`}>
      {result.success ? (
        <>
          {/* 成功状态 */}
          <div className="flex justify-center mb-6">
            <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center">
              <i className="ri-checkbox-circle-line text-green-500 text-4xl"></i>
            </div>
          </div>
          
          <h2 className={`font-bold text-gray-900 mb-4 ${isElderMode ? 'text-3xl' : 'text-xl'}`}>
            挂号成功！
          </h2>
          
          {/* 就诊信息卡片 */}
          <div className="bg-blue-50 rounded-xl p-6 mb-8 border border-blue-100 max-w-md mx-auto">
            <div className="space-y-4">
              {result.patientName && (
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">患者姓名：</span>
                  <span className="font-medium">{result.patientName}</span>
                </div>
              )}
              <div className="flex justify-between items-center">
                <span className="text-gray-600">科室名称：</span>
                <span className="font-medium">{result.departmentName}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">就诊地点：</span>
                <span className="font-medium">{result.location}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">您的号码：</span>
                <span className={`font-bold ${isElderMode ? 'text-4xl' : 'text-2xl'}`}>
                  {result.queueNo}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">当前队列：</span>
                <span className="font-medium">{result.queueLength}人</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">预计等待：</span>
                <span className="font-medium">{result.estimatedWaitingTime}分钟</span>
              </div>
              {result.status && (
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">当前状态：</span>
                  <span className="font-medium">{result.status}</span>
                </div>
              )}
            </div>
          </div>
          
          <div className="bg-yellow-50 rounded-xl p-4 mb-8 border border-yellow-100 max-w-md mx-auto">
            <p className="text-yellow-700 flex items-start">
              <i className="ri-information-line mr-2 mt-1"></i>
              {result.tips}
            </p>
          </div>
        </>
      ) : (
        <>
          {/* 失败状态 */}
          <div className="flex justify-center mb-6">
            <div className="w-24 h-24 bg-red-100 rounded-full flex items-center justify-center">
              <i className="ri-close-circle-line text-red-500 text-4xl"></i>
            </div>
          </div>
          
          <h2 className={`font-bold text-gray-900 mb-4 ${isElderMode ? 'text-3xl' : 'text-xl'}`}>
            挂号失败
          </h2>
          
          <div className="bg-red-50 rounded-xl p-4 mb-8 border border-red-100 max-w-md mx-auto">
            <p className="text-red-700">{result.tips}</p>
          </div>
        </>
      )}
      
      <div className="flex flex-col sm:flex-row justify-center gap-4">
        <button
          onClick={onBackToHome}
          className={`px-6 py-3 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition-colors ${
            isElderMode ? 'text-xl px-8 py-4' : 'text-base'
          }`}
        >
          <i className="ri-home-line mr-2"></i>
          返回首页
        </button>
        {result.success && (
          <button
            onClick={onQueryQueue}
            className={`px-6 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl hover:from-blue-600 hover:to-indigo-700 shadow-md hover:shadow-lg transition-all ${
              isElderMode ? 'text-xl px-8 py-4' : 'text-base'
            }`}
          >
            <i className="ri-list-check mr-2"></i>
            查询队列
          </button>
        )}
      </div>
    </div>
  );
}