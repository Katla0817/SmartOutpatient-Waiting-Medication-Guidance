import express from 'express';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(express.json());

// In-memory stores (mock data)
const departmentMap = {
  'dept-internal': { id: 'dept-internal', name: '内科', location: '一楼A区' },
  'dept-ent': { id: 'dept-ent', name: '耳鼻喉', location: '二楼B区' },
  'dept-resp': { id: 'dept-resp', name: '呼吸科', location: '三楼C区' }
};

const patients = [
  { patientId: 'p1', name: '王小明', idCard: '110*********1234', registrationNo: 'R-2025001', departmentId: 'dept-internal', symptoms: '头痛、发热38.5℃、咳嗽' },
  { patientId: 'p2', name: '李华', idCard: '320*********5678', registrationNo: 'R-2025002', departmentId: 'dept-ent', symptoms: '咽痛、流涕' }
];

let queue = [
  {
    id: 'seed-1',
    patientName: '张三',
    idCard: '110*********1234',
    queueNo: 'A101',
    status: 'calling',
    estimatedWaitingTime: 0,
    department: '内科',
    location: '一楼A区',
    joinedAt: Date.now() - 5 * 60 * 1000
  },
  {
    id: 'seed-2',
    patientName: '李四',
    idCard: '320*********5678',
    queueNo: 'A102',
    status: 'waiting',
    estimatedWaitingTime: 8,
    department: '内科',
    location: '一楼A区',
    joinedAt: Date.now() - 3 * 60 * 1000
  }
];

const drugStore = [
  {
    id: 'drug-1',
    name: '对乙酰氨基酚',
    aliases: ['扑热息痛', 'Paracetamol'],
    indications: '用于普通感冒或流感引起的发热、轻中度疼痛。',
    dosage: '成人每次0.5~1g，每4~6小时一次；24小时不超过4g。',
    cautions: '肝功能异常慎用，避免与含对乙酰氨基酚的其他药同服。',
    pharmacologicalAction: '中枢抑制前列腺素合成，解热镇痛。',
    adverseReactions: '罕见肝损伤、皮疹，偶见恶心。',
    contraindications: '重度肝功能不全者禁用。',
    precautions: '避免重复用药，按医嘱限量使用。',
    specialPopulation: '孕妇、儿童需遵医嘱。'
  },
  {
    id: 'drug-2',
    name: '布洛芬',
    aliases: ['Ibuprofen'],
    indications: '用于缓解轻中度疼痛，如头痛、牙痛、关节痛，并退热。',
    dosage: '成人每次0.2~0.4g，每4~6小时一次；24小时不超过1.2g（OTC）。',
    cautions: '胃溃疡、出血倾向、哮喘者慎用，避免空腹服用。',
    pharmacologicalAction: 'NSAID，通过抑制前列腺素合成发挥镇痛、解热、抗炎。',
    adverseReactions: '可能胃部不适、头晕，罕见过敏反应。',
    contraindications: '活动性消化道溃疡、严重心肾功能不全者禁用。',
    precautions: '饭后服用，注意与抗凝药物相互作用。',
    specialPopulation: '孕晚期、哺乳期慎用；儿童遵医嘱。'
  },
  {
    id: 'drug-3',
    name: '阿莫西林',
    aliases: ['Amoxicillin'],
    indications: '青霉素类抗生素，适用于敏感菌所致的呼吸道、泌尿道等感染。',
    dosage: '成人每次0.5g，每8小时一次；具体遵医嘱完成疗程。',
    cautions: '青霉素过敏禁用，注意皮疹、腹泻等不良反应。',
    pharmacologicalAction: '抑制细菌细胞壁合成，杀菌作用。',
    adverseReactions: '可能胃肠不适、皮疹，极少数过敏性休克。',
    contraindications: '青霉素过敏史者禁用。',
    precautions: '全程足量，不可自行停药；关注过敏史。',
    specialPopulation: '肾功能不全需调整剂量。'
  }
];

const notifications = [];

const formatTime = () => {
  const d = new Date();
  return `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}:${d
    .getSeconds()
    .toString()
    .padStart(2, '0')}`;
};

const addNote = (msg) => {
  notifications.unshift({ id: crypto.randomUUID(), message: msg, time: formatTime() });
  if (notifications.length > 20) notifications.pop();
};

// Helpers
const createQueueNo = (prefix = 'A') => `${prefix}${Math.floor(Math.random() * 900 + 100)}`;

// Queue APIs
app.post('/api/queue/register', (req, res) => {
  const { name, idCard, departmentId = 'dept-internal' } = req.body || {};
  const dept = departmentMap[departmentId];
  if (!name || !idCard || !dept) {
    return res.status(400).json({ message: '缺少姓名/身份证号/科室' });
  }
  const waitingCount = queue.filter((q) => q.status !== 'done').length;
  const estimatedWaitingTime = Math.max(5, waitingCount * 5);
  const queueNo = createQueueNo(dept.id === 'dept-internal' ? 'A' : 'B');
  const item = {
    id: crypto.randomUUID(),
    patientName: name,
    idCard,
    queueNo,
    status: 'waiting',
    estimatedWaitingTime,
    department: dept.name,
    location: dept.location,
    joinedAt: Date.now()
  };
  queue.push(item);
  addNote(`新挂号 ${queueNo} 已加入队列，前方 ${waitingCount} 人`);
  res.json({
    queueNo,
    estimatedWaitingTime,
    waitingCount: waitingCount + 1,
    department: dept.name,
    location: dept.location
  });
});

app.get('/api/queue/status', (req, res) => {
  const { idCard, queueNo } = req.query;
  const item = queue.find((q) => (idCard && q.idCard === idCard) || (queueNo && q.queueNo === queueNo));
  if (!item) return res.status(404).json({ message: '未找到队列记录' });
  const waitingAhead = queue
    .filter((q) => q.status === 'waiting')
    .findIndex((q) => q.id === item.id);
  res.json({
    queueNo: item.queueNo,
    status: item.status,
    estimatedWaitingTime: item.estimatedWaitingTime,
    waitingAhead: waitingAhead >= 0 ? waitingAhead : 0,
    notifications
  });
});

app.post('/api/queue/call-next', (req, res) => {
  const waitingIdx = queue.findIndex((q) => q.status === 'waiting');
  if (waitingIdx < 0) return res.json({ message: '无等待患者' });
  queue[waitingIdx].status = 'calling';
  queue[waitingIdx].estimatedWaitingTime = 0;
  addNote(`${queue[waitingIdx].queueNo} 正在叫号，请患者前往诊室`);
  res.json({ queueNo: queue[waitingIdx].queueNo, patientName: queue[waitingIdx].patientName });
});

app.post('/api/queue/mark-done', (req, res) => {
  const callingIdx = queue.findIndex((q) => q.status === 'calling');
  if (callingIdx < 0) return res.json({ message: '当前无叫号中患者' });
  queue[callingIdx].status = 'done';
  queue[callingIdx].estimatedWaitingTime = 0;
  addNote(`${queue[callingIdx].queueNo} 已完成，就诊结束`);
  res.json({ queueNo: queue[callingIdx].queueNo, patientName: queue[callingIdx].patientName });
});

// Triage APIs
function findPatient(queryNo) {
  return patients.find((p) => p.idCard === queryNo || p.registrationNo === queryNo);
}

function checkMatch(deptId, symptoms) {
  if (deptId === 'dept-ent' && symptoms.includes('咳嗽')) return false;
  return true;
}

function recommendDepartment(symptoms) {
  if (symptoms.includes('咳嗽') || symptoms.includes('发热')) return departmentMap['dept-resp'];
  return departmentMap['dept-internal'];
}

app.post('/api/triage/query', (req, res) => {
  const { queryNo } = req.body || {};
  const patient = findPatient((queryNo || '').trim());
  if (!patient) return res.status(404).json({ message: '未查询到患者挂号信息，请核对输入' });
  const applyDept = departmentMap[patient.departmentId];
  const isMatch = checkMatch(patient.departmentId, patient.symptoms);
  const targetDept = isMatch ? applyDept : recommendDepartment(patient.symptoms);
  res.json({
    patientName: patient.name,
    patientId: patient.patientId,
    applyDepartment: applyDept?.name,
    targetDepartment: targetDept?.name,
    departmentLocation: targetDept?.location,
    matchStatus: isMatch ? '匹配' : '已调整',
    symptoms: patient.symptoms
  });
});

app.post('/api/triage/confirm', (req, res) => {
  const { queryNo } = req.body || {};
  const patient = findPatient((queryNo || '').trim());
  if (!patient) return res.status(404).json({ message: '未查询到患者挂号信息，请核对输入' });
  let targetDept = departmentMap[patient.departmentId];
  let matchStatus = '匹配';
  if (!checkMatch(patient.departmentId, patient.symptoms)) {
    targetDept = recommendDepartment(patient.symptoms);
    matchStatus = '已调整';
  }
  const existingMax = queue
    .filter((q) => q.department === targetDept.name)
    .reduce((max, item) => Math.max(max, parseInt(item.queueNo.replace(/\D/g, '') || '0', 10)), 0);
  const queueNoNumeric = existingMax + 1;
  const queueNo = createQueueNo(targetDept.id === 'dept-internal' ? 'A' : 'B') + queueNoNumeric;

  const newItem = {
    id: crypto.randomUUID(),
    patientName: patient.name,
    idCard: patient.idCard,
    queueNo,
    status: 'waiting',
    estimatedWaitingTime: Math.max(5, queue.filter((q) => q.status !== 'done').length * 5),
    department: targetDept.name,
    location: targetDept.location,
    joinedAt: Date.now()
  };
  queue.push(newItem);
  addNote(`分诊完成：${patient.name} -> ${targetDept.name}，序号 ${queueNoNumeric}`);
  res.json({
    patientName: patient.name,
    patientId: patient.patientId,
    targetDepartment: targetDept.name,
    queueNo: queueNoNumeric,
    departmentLocation: targetDept.location,
    matchStatus,
    applyDepartment: departmentMap[patient.departmentId]?.name,
    symptoms: patient.symptoms
  });
});

// Drug APIs
app.get('/api/drug/search', (req, res) => {
  const q = (req.query.q || '').toLowerCase().trim();
  if (!q) return res.json(drugStore);
  const results = drugStore.filter(
    (d) =>
      d.name.toLowerCase().includes(q) ||
      d.aliases.some((a) => a.toLowerCase().includes(q)) ||
      d.indications.toLowerCase().includes(q)
  );
  res.json(results);
});

app.get('/api/drug/detail/:id', (req, res) => {
  const drug = drugStore.find((d) => d.id === req.params.id);
  if (!drug) return res.status(404).json({ message: '未找到药品' });
  // TODO: record patient query history if auth context is available
  res.json(drug);
});

// Health check
app.get('/health', (_req, res) => res.send('ok'));

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`API server listening on http://localhost:${PORT}`);
});

